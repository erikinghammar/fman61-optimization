if abs(F_prim_lambda) > -sigma * F_prim_0
    iter = 0;
    while F_prim_lambda < 0 && iter < MAX_ITER
        a = lambda;
        lambda = alpha * lambda;
        F_prim_lambda = num_gradient(F,lambda);
        N_eval = N_eval +2;
    end
    b = lambda;
    lambda = (a + b)/2;
    F_prim_lambda = num_gradient(F,lambda);
    